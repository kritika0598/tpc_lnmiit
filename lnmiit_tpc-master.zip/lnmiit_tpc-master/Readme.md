Placement Cell LNMIIT
